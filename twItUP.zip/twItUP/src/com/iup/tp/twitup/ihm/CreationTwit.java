package com.iup.tp.twitup.ihm;

import com.iup.tp.twitup.core.Twitup;
import com.iup.tp.twitup.datamodel.User;

import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.util.Set;
import java.util.UUID;

/**
 * Created by Romain on 12/03/15.
 */
public class CreationTwit extends JPanel {

    private Twitup twitup;
    private TwitupMainView twitupMainView;
    private JLabel twitLabel;
    private JTextArea twitText;
    private JButton EnvoiTwit;
    private ImageIcon exit50 = new ImageIcon("/Users/Romain/Desktop/IHM/twItUP/src/resources/images/exitIcon_50.png");



    public CreationTwit(Twitup twitup,TwitupMainView twitupMainView){
        this.setLayout(new GridBagLayout());
        this.twitup=twitup;
        this.twitupMainView = twitupMainView;
        init();
    }


    public void init(){
        GridBagConstraints c = new GridBagConstraints();

        twitLabel = new JLabel("Twit :");
        twitText = new JTextArea();
        twitText.setPreferredSize(new Dimension(200,100));
        EnvoiTwit = new JButton("Envoyer Twit");


        c.fill = GridBagConstraints.HORIZONTAL;
        c.gridx = 1;
        c.gridy = 1;

        this.add(twitLabel,c);

        c.fill = GridBagConstraints.HORIZONTAL;
        c.gridx = 2;
        c.gridy = 1;
        c.gridwidth = 2;

        this.add(twitText,c);

        c.gridwidth = 1;
        c.fill = GridBagConstraints.HORIZONTAL;
        c.gridx = 1;
        c.gridy = 3;

        this.add(EnvoiTwit,c);


        EnvoiTwit.addActionListener(
                new ActionListener() {
                    public void actionPerformed(ActionEvent e) {
                        twitupMainView.EnvoiTwit();

                    }
                }
        );

    }
}
